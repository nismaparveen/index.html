let suggestions = [
    "Global",
    "Germarny",
    "Glow",
    "Global Positioning System",
    "Globalization",
    "World",    
    "Wikipedia",
    "World War II"
];

// getting all required elements
const searchInput = document.querySelector(".search-box");
const input = searchInput.querySelector("input");
const resultBox = searchInput.querySelector(".resultBox");
const icon = searchInput.querySelector(".icon");
let linkTag = searchInput.querySelector("a");
let webLink;

// if user presses any key and releases
input.onkeyup = (e) => {
    if (e.key === "Enter") {
        console.log(e)
        let firstSuggestion = resultBox.querySelector("li");
        if (firstSuggestion) {
            select(firstSuggestion);
        }
    }
    let userData = e.target.value; //user entered data
    let emptyArray = [];
    if (userData) {
        emptyArray = suggestions.filter((data) => {
            //filtering array value and user characters to lowercase and return only those words which start with user entered chars
            return data.toLocaleLowerCase().startsWith(userData.toLocaleLowerCase());
        });
        emptyArray = emptyArray.map((data) => {
            // passing return data inside li tag
            return data = '<li>' + data + '</li>';
        });
        searchInput.classList.add("active"); //show autocomplete box
        showSuggestions(emptyArray);
        let allList = resultBox.querySelectorAll("li");
        for (let i = 0; i < allList.length; i++) {
            //adding onclick attribute in all li tag
            allList[i].setAttribute("onclick", "select(this)");
        }
    } else {
        searchInput.classList.remove("active"); //hide autocomplete box
    }
    
}

function showSuggestions(list) {
    let listData;
    if (!list.length) {
        userValue = input.value;
        listData = '<li>' + userValue + '</li>';
    } else {
        listData = list.join('');
    }
    resultBox.innerHTML = listData;
}

icon.onclick = () => {
    let firstSuggestion = resultBox.querySelector("li");
    if (firstSuggestion) {
        select(firstSuggestion);
    }
}
function select(element) {
    let selectData = element.textContent;
    input.value = selectData;
    webLink = `${selectData}.html`;
    linkTag.setAttribute("href", webLink);
    linkTag.click();
    searchInput.classList.remove("active");
}
